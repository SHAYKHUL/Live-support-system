require('dotenv').config(); // Load environment variables
const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const path = require('path');
const session = require('express-session');
const rateLimit = require('express-rate-limit');
const winston = require('winston');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

const PORT = process.env.PORT || 3000;

// Logger setup
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [
        new winston.transports.Console(),
        new winston.transports.File({ filename: 'app.log' })
    ]
});

// Middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(session({
    secret: process.env.SESSION_SECRET || 'default-secret',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

// Rate limiter for login endpoint
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10, // Limit each IP to 10 requests per windowMs
    message: { success: false, message: 'Too many login attempts, please try again later.' }
});

// Dummy agent login credentials
const agentUsers = {
    "agent1": "pass123",
    "agent2": "pass456"
};

let agents = {};  // socketId -> { username, available }
let visitors = {};  // socketId -> visitor
let visitorAssignments = {}; // visitorId -> agentSocketId
let visitorQueue = []; // Queue for unassigned visitors

// Serve the HTML page for agent login
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/html/login.html'));
});

// Dummy agent login (POST)
app.post('/api/login', loginLimiter, (req, res) => {
    const { username, password } = req.body;
    if (agentUsers[username] === password) {
        req.session.agent = username;
        return res.json({ success: true });
    }
    res.status(401).json({ success: false, message: 'Invalid credentials' });
});

// Serve the HTML page for agents
app.get('/agent', (req, res) => {
    if (!req.session.agent) {
        return res.redirect('/login');
    }
    res.sendFile(path.join(__dirname, 'public/html/agent.html'));
});

// Serve the HTML page for visitors
app.get('/visitor', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/html/visitor.html'));
});

// Centralized error handling middleware
app.use((err, req, res, next) => {
    logger.error(err.stack);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
});

// Socket.IO setup
io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    if (token === process.env.SOCKET_AUTH_TOKEN) {
        return next();
    }
    return next(new Error('Unauthorized'));
});

// Enhanced visitor assignment logic
function updateVisitorQueue() {
    io.emit('visitor_queue_update', { queue: visitorQueue });
}

// Notify agents of a new visitor
function notifyAgentsOfNewVisitor(visitorId) {
    Object.keys(agents).forEach(agentSocketId => {
        if (agents[agentSocketId].available) {
            io.to(agentSocketId).emit('incoming_call', { visitorId });
        }
    });
}

// Assign visitor to an available agent
function assignVisitorToAgent() {
    while (visitorQueue.length > 0) {
        const visitorId = visitorQueue[0];
        const agentSocketId = Object.keys(agents).find(agentId =>
            agents[agentId].available && !Object.values(visitorAssignments).includes(agentId)
        );

        if (agentSocketId) {
            visitorAssignments[visitorId] = agentSocketId;
            io.to(agentSocketId).emit('new_visitor', { visitorId });
            io.to(visitorId).emit('assigned', { agentId: agentSocketId });
            logger.info(`Visitor ${visitorId} assigned to agent ${agentSocketId}`);
            visitorQueue.shift(); // Remove from queue
        } else {
            break; // No available agents
        }
    }
}

// Handle manual visitor assignment
io.on('connection', socket => {
    logger.info(`New socket connected: ${socket.id}`);

    // Handle new visitor join
    socket.on('visitor_join', () => {
        visitors[socket.id] = socket;
        visitorQueue.push(socket.id);
        notifyAgentsOfNewVisitor(socket.id);
    });

    // Handle agent join (login)
    socket.on('agent_join', (username) => {
        if (!username) {
            logger.warn(`Agent join attempt without username: ${socket.id}`);
            return socket.disconnect();
        }
        agents[socket.id] = { username, available: true };
        io.to(socket.id).emit('agent_ready');
        logger.info(`Agent ${username} connected`);
        updateVisitorQueue();
        assignVisitorToAgent();
    });

    // Handle agent accepting a call
    socket.on('accept_call', ({ visitorId }) => {
        if (visitorAssignments[visitorId]) {
            socket.emit('call_taken', { visitorId });
            return;
        }
        visitorAssignments[visitorId] = socket.id;
        agents[socket.id].available = false;
        io.to(socket.id).emit('new_visitor', { visitorId });
        io.to(visitorId).emit('assigned', { agentId: socket.id });
        logger.info(`Visitor ${visitorId} assigned to agent ${socket.id}`);
        visitorQueue = visitorQueue.filter(id => id !== visitorId);
        io.emit('visitor_queue_update', { queue: visitorQueue });
    });

    // Handle agent accepting a visitor
    socket.on('accept_visitor', ({ visitorId }) => {
        if (!agents[socket.id]) {
            logger.warn(`Unauthorized agent tried to accept visitor: ${socket.id}`);
            return;
        }
        if (visitorQueue.includes(visitorId)) {
            visitorAssignments[visitorId] = socket.id;
            io.to(socket.id).emit('new_visitor', { visitorId });
            io.to(visitorId).emit('assigned', { agentId: socket.id });
            logger.info(`Visitor ${visitorId} accepted by agent ${socket.id}`);
            visitorQueue = visitorQueue.filter(id => id !== visitorId); // Remove from queue
            updateVisitorQueue();
        } else {
            logger.warn(`Visitor ${visitorId} not found in queue`);
        }
    });

    // Handle visitor message
    socket.on('visitor_message', ({ message }) => {
        const agentSocketId = visitorAssignments[socket.id];

        // If the visitor is not yet assigned to an agent, trigger a "calling" notification
        if (!agentSocketId) {
            logger.info(`Visitor ${socket.id} sent their first message. Triggering incoming call.`);
            
            // Add visitor to the queue if not already present
            if (!visitorQueue.includes(socket.id)) {
                visitorQueue.push(socket.id);
            }

            // Notify all available agents about the new visitor
            notifyAgentsOfNewVisitor(socket.id);
            return; // Exit early since no agent is assigned yet
        }

        // If the visitor is already assigned to an agent, forward the message
        if (agentSocketId) {
            io.to(agentSocketId).emit('new_message', {
                from: 'visitor',
                message,
                timestamp: new Date().toLocaleTimeString()
            });
            logger.info(`Message from visitor ${socket.id} to agent ${agentSocketId}: ${message}`);
        } else {
            logger.warn(`Visitor ${socket.id} tried to send a message without an assigned agent`);
        }
    });

    // Handle agent message
    socket.on('agent_message', ({ toVisitorId, message }) => {
        if (visitors[toVisitorId]) {
            io.to(toVisitorId).emit('new_message', {
                from: 'agent',
                message
            });
            logger.info(`Message from agent ${socket.id} to visitor ${toVisitorId}: ${message}`);
        } else {
            logger.warn(`Agent ${socket.id} tried to send a message to an unassigned visitor`);
        }
    });

    // Handle agent availability toggle
    socket.on('toggle_availability', ({ available }) => {
        if (agents[socket.id]) {
            agents[socket.id].available = available;
            logger.info(`Agent ${socket.id} set availability to ${available}`);
            updateVisitorQueue();
            assignVisitorToAgent();
        }
    });

    // On disconnect
    socket.on('disconnect', () => {
        logger.info(`Socket disconnected: ${socket.id}`);
        
        // Remove agent or visitor from their lists
        if (agents[socket.id]) {
            delete agents[socket.id];
        }

        if (visitors[socket.id]) {
            delete visitors[socket.id];
        }

        // Remove the visitor's assignment to an agent
        for (let visitorId in visitorAssignments) {
            if (visitorAssignments[visitorId] === socket.id || visitorId === socket.id) {
                delete visitorAssignments[visitorId];
            }
        }

        // Update the visitor queue
        visitorQueue = visitorQueue.filter(id => id !== socket.id);
        updateVisitorQueue();
        assignVisitorToAgent();
    });
});

server.listen(PORT, () => logger.info(`Server is running on http://localhost:${PORT}`));